import { Component } from '@angular/core';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css','./game.bg.component.css',]
})
export class GameComponent {

  corLadoA = 'red'
  corLadoB ='blue'


  

}
